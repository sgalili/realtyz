/* Realtyz Group Sync — background worker.
 *
 * Every 60 seconds (while the browser is open) it asks the Realtyz backend for
 * Facebook group posts that are due, opens the group in a background tab,
 * runs the local posting automation (poster.js) and reports the outcome back.
 */

const SUPABASE_URL = 'https://gvylyghwfysvydygqdtf.supabase.co';
const ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd2eWx5Z2h3ZnlzdnlkeWdxZHRmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0MjMxMDEsImV4cCI6MjA5NTk5OTEwMX0.3_sZy9BP9GIXO1yA1PoFYVdO0tDYzx7oFbfflsdk3aE';

const ALARM = 'rz-queue-poll';
const TOKEN_KEY = 'rzSyncToken';
const STATE_KEY = 'rzQueueState';
const JOB_TIMEOUT_MS = 4 * 60 * 1000; // hard ceiling per job

let running = false;

/* ── helpers ────────────────────────────────────────────────────────────── */

const getToken = () =>
  new Promise((resolve) => chrome.storage.local.get([TOKEN_KEY], (r) => resolve((r || {})[TOKEN_KEY] || null)));

const setState = (patch) =>
  new Promise((resolve) => {
    chrome.storage.local.get([STATE_KEY], (r) => {
      const next = Object.assign({}, (r || {})[STATE_KEY] || {}, patch, { updated_at: Date.now() });
      chrome.storage.local.set({ [STATE_KEY]: next }, () => resolve(next));
    });
  });

const api = async (fn, body) => {
  const res = await fetch(`${SUPABASE_URL}/functions/v1/${fn}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      apikey: ANON_KEY,
      Authorization: `Bearer ${ANON_KEY}`,
    },
    body: JSON.stringify(body),
  });
  let json = {};
  try { json = await res.json(); } catch (e) { /* noop */ }
  return { status: res.status, json };
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const waitForTabLoad = (tabId, timeoutMs = 45000) =>
  new Promise((resolve) => {
    const started = Date.now();
    const tick = () => {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError || !tab) return resolve(false);
        if (tab.status === 'complete') return resolve(true);
        if (Date.now() - started > timeoutMs) return resolve(false);
        setTimeout(tick, 500);
      });
    };
    tick();
  });

const sendToTab = (tabId, payload, timeoutMs) =>
  new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve({ ok: false, reason: 'תם הזמן להרצת הפרסום בדפדפן' });
    }, timeoutMs);
    try {
      chrome.tabs.sendMessage(tabId, payload, (res) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (chrome.runtime.lastError) {
          return resolve({ ok: false, reason: 'לא ניתן להריץ את הפרסום בעמוד הקבוצה' });
        }
        resolve(res || { ok: false, reason: 'לא התקבלה תשובה מעמוד הקבוצה' });
      });
    } catch (e) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ ok: false, reason: String((e && e.message) || e) });
    }
  });

const groupUrl = (job) => {
  const raw = String(job.group_url || '').trim();
  if (/^https?:\/\/(www\.)?facebook\.com\/groups\//i.test(raw)) return raw.split('?')[0];
  const id = String(job.group_id || '').trim();
  return id ? `https://www.facebook.com/groups/${id}` : null;
};

/* ── one job ────────────────────────────────────────────────────────────── */

async function runJob(token, job) {
  const url = groupUrl(job);
  if (!url) return report(token, job, false, 'כתובת הקבוצה חסרה');
  if (!String(job.message || '').trim()) return report(token, job, false, 'תוכן הפוסט ריק');

  let tabId = null;
  try {
    const tab = await chrome.tabs.create({ url, active: false });
    tabId = tab.id;
    const loaded = await waitForTabLoad(tabId);
    if (!loaded) {
      await report(token, job, false, 'עמוד הקבוצה לא נטען בזמן');
      return;
    }
    await sleep(2500); // let Facebook hydrate the feed

    const result = await sendToTab(
      tabId,
      {
        source: 'realtyz-extension',
        type: 'RZ_POST_TO_GROUP',
        job: {
          id: job.id,
          message: job.message,
          image_url: job.image_url || null,
          first_comment: job.first_comment || null,
          link: job.link || null,
        },
      },
      JOB_TIMEOUT_MS,
    );

    await report(token, job, result.ok === true, result.reason || null, result.post_url || null);
  } catch (e) {
    await report(token, job, false, String((e && e.message) || e));
  } finally {
    if (tabId != null) {
      try { await chrome.tabs.remove(tabId); } catch (e) { /* noop */ }
    }
  }
}

async function report(token, job, ok, reason, postUrl) {
  await api('ext-queue-report', {
    token,
    job_id: job.id,
    ok: !!ok,
    reason: ok ? null : (reason || 'פרסום בדפדפן נכשל'),
    post_url: postUrl || null,
  });
  await setState(
    ok
      ? { last_success_at: Date.now(), last_error: null }
      : { last_error: reason || 'פרסום בדפדפן נכשל', last_error_at: Date.now() },
  );
}

/* ── poll loop ──────────────────────────────────────────────────────────── */

async function poll() {
  if (running) return;
  running = true;
  try {
    const token = await getToken();
    if (!token) {
      await setState({ paired: false, last_error: 'התוסף לא מחובר לחשבון Realtyz' });
      return;
    }

    const { status, json } = await api('ext-queue-claim', {
      token,
      limit: 2,
      user_agent: navigator.userAgent,
    });

    if (status === 401) {
      await setState({ paired: false, last_error: 'מפתח הסנכרון אינו תקף — חבר את התוסף מחדש' });
      return;
    }
    if (!json || json.ok !== true) {
      await setState({ paired: true, last_error: 'החיבור לשרת Realtyz נכשל' });
      return;
    }

    await setState({ paired: true, last_poll_at: Date.now(), last_error: null });

    const jobs = Array.isArray(json.jobs) ? json.jobs : [];
    for (const job of jobs) {
      await runJob(token, job);
      await sleep(8000); // gentle pacing between group posts
    }
  } catch (e) {
    await setState({ last_error: String((e && e.message) || e) });
  } finally {
    running = false;
  }
}

chrome.alarms.create(ALARM, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === ALARM) poll(); });
chrome.runtime.onInstalled.addListener(() => { chrome.alarms.create(ALARM, { periodInMinutes: 1 }); poll(); });
chrome.runtime.onStartup.addListener(() => poll());

/* ── messages from the app page (content.js) ────────────────────────────── */

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return;

  if (msg.type === 'RZ_EXT_PAIR' && typeof msg.token === 'string' && msg.token) {
    chrome.storage.local.set({ [TOKEN_KEY]: msg.token }, async () => {
      await setState({ paired: true, last_error: null });
      poll();
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === 'RZ_EXT_STATUS') {
    chrome.storage.local.get([TOKEN_KEY, STATE_KEY], (r) => {
      const state = (r || {})[STATE_KEY] || {};
      sendResponse({ ok: true, paired: !!(r || {})[TOKEN_KEY], state });
    });
    return true;
  }

  if (msg.type === 'RZ_EXT_POLL_NOW') {
    poll();
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'RZ_EXT_UNPAIR') {
    chrome.storage.local.remove([TOKEN_KEY], () => sendResponse({ ok: true }));
    return true;
  }
});
